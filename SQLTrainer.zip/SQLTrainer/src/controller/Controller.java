package controller;

import db.Database;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static java.lang.Thread.sleep;

public class Controller {
    @FXML
    private TextArea textArea;
    @FXML
    private Label msgLabel;
    @FXML
    private TextField syntaxCorrectField;
    @FXML
    private TextArea taskTextArea;
    boolean isSyntaxCorrect = true;
    int numberOfSyntaxLines = 0;
    int numberOfSqlLines = 0;
    private List<String> lines = new ArrayList<>();
    private List<String> lines2 = new ArrayList<>();
    Database db = Database.getInstance();
    String FILENAME = "noRows.txt";
    String choosenFile = "";
    public Controller() throws SQLException {
    }

    @FXML
    void checkButtonOnCLick(ActionEvent event) throws SQLException, IOException {

        readTextarea();
        if(textArea.getText().toUpperCase().contains("FROM")){  //is this table in the database?
            isSyntaxCorrect = isTableInDatabase();
        }
        isSyntaxCorrect = rightRowsCount();
        if(isSyntaxCorrect){
            if (lines == null){
                msgLabel.setText("The file is empty or you didn't import it yet!");
            }else{
                for (int i = 0; i < lines.size(); i++){
                    String mystring = lines.get(i);
                    String arr[] = mystring.split(" ", 2);
                    System.out.println("fw: " + arr[0] + "  |  rest: " + arr[1]);
                }
            }
            try {
                for (int i = 0; i < lines.size(); i++) {
                    checkColumns(i);
                    if (isSyntaxCorrect) syntaxCorrectField.setText("Syntax " + (i + 1) + " korrekt");
                    else syntaxCorrectField.setText("Syntax " + (i + 1) + " inkorrekt");
                }
            }
            catch (Exception e){
                System.out.println(e);
            }
        }
    }

    private boolean rightRowsCount() throws IOException, SQLException {
        boolean ret = false;
        List<String> fileLines = Files.readAllLines(Paths.get("FILENAME"));
        int count = db.getInstance().countRows(textArea.getText());
        String[] a = choosenFile.split(".");
        int b = Integer.parseInt(a[0]);
        if(Integer.parseInt(fileLines.get(b-1)) == count){
            ret = true;
        }

        return ret;
    }

    private Boolean isTableInDatabase() throws SQLException {
        boolean ret = false;
        boolean start = false;
        boolean end = false;
        String table = "";
        String[] arr = textArea.getText().toUpperCase().split("FROM");
        String text = arr[1];
        for(int i = 0;i < text.length()&& !end;i++){
            if(text.indexOf(i) != ' '){
                table += text.indexOf(i);
                start = true;
            }
            else if(text.indexOf(i) != ' ' && start){
                end= true;
            }
        }

        db.getInstance().tableExist(table);
        return ret;
    }

    private void readTextarea() {
        String txt = "";
        int cnt = 0;
        String aText = textArea.getText();

        System.out.println("Count : " + cnt);
       // if(countSemicolon() == 1) {
            lines.add(textArea.getText());
            numberOfSyntaxLines = 1;
            msgLabel.setText(cnt + " lines have been imported!");
            System.out.println("Count : " + numberOfSyntaxLines);
            System.out.println(textArea.getText());
            System.out.println("line1: " + lines.get(0));
            // isCorrecto();
       // }
    }



    private void checkColumns(int index)
    {
        String syntax_line = lines.get(index);
        String start = "";
        String input = "";
        String from = "";
        int lastIndex = syntax_line.lastIndexOf(';');
        boolean checkFalse = false;

        for (int i = 0; i < syntax_line.length(); i++){
            if(syntax_line.toUpperCase().charAt(i) == 'S' && syntax_line.toUpperCase().charAt(i + 1) == 'E' &&
            syntax_line.toUpperCase().charAt(i + 2) == 'L' && syntax_line.toUpperCase().charAt(i + 3) == 'E' &&
                    syntax_line.toUpperCase().charAt(i + 4) == 'C' && syntax_line.toUpperCase().charAt(i + 5) == 'T')
                start = "SELECT";
            else if(syntax_line.toUpperCase().charAt(i) == 'U' && syntax_line.toUpperCase().charAt(i+1) == 'P' &&
                    syntax_line.toUpperCase().charAt(i+2) == 'D' && syntax_line.toUpperCase().charAt(i+3) == 'A' &&
                    syntax_line.toUpperCase().charAt(i+4) == 'T' && syntax_line.toUpperCase().charAt(i+5) == 'E') start = "UPDATE";
            else if(syntax_line.toUpperCase().charAt(i) == 'C' && syntax_line.toUpperCase().charAt(i+1) == 'R' &&
                    syntax_line.toUpperCase().charAt(i+2) == 'E' && syntax_line.toUpperCase().charAt(i+3) == 'A' &&
                    syntax_line.toUpperCase().charAt(i+4) == 'T' && syntax_line.toUpperCase().charAt(i+5) == 'E') start = "CREATE";
            else if(syntax_line.toUpperCase().charAt(i) == 'S' && syntax_line.toUpperCase().charAt(i+1) == 'E' &&
                    syntax_line.toUpperCase().charAt(i+2) == 'T') start = "SET";
            else if(syntax_line.toUpperCase().charAt(i) == 'F' && syntax_line.toUpperCase().charAt(i + 1) == 'R' &&
                    syntax_line.toUpperCase().charAt(i+2) == 'O' && syntax_line.toUpperCase().charAt(i+3) == 'M')
                from = "FROM";
            else if(syntax_line.toUpperCase().charAt(i) == '*' && syntax_line.toUpperCase().charAt(i - 1) == ' ' &&
                    syntax_line.toUpperCase().charAt(i+1) == ' ')
                input = "*";
            else if(lastIndex == -1 ){
                isSyntaxCorrect = false;
                checkFalse = true;
                break;
            }
            else if(syntax_line.charAt(i) == ';' && i + 1 != syntax_line.length()){
                if(Character.isLetterOrDigit(syntax_line.toUpperCase().charAt(i+1))){
                    isSyntaxCorrect = false;
                    checkFalse = true;
                    break;
                }
            }
            else if(syntax_line.toUpperCase().charAt(i) == ' '){
                if(syntax_line.toUpperCase().charAt(i+1) == ',' || Character.isDigit(syntax_line.toUpperCase().charAt(i+1))){
                    isSyntaxCorrect = false;
                    checkFalse = true;
                    break;
                }
                else if(syntax_line.toUpperCase().charAt(i+1) == ',' && syntax_line.toUpperCase().charAt(i+2) == ' ' &&
                        syntax_line.toUpperCase().charAt(i+3) == 'F' && syntax_line.toUpperCase().charAt(i+4) == 'R' &&
                        syntax_line.toUpperCase().charAt(i+5) == 'O' && syntax_line.toUpperCase().charAt(i+6) == 'M'){
                    isSyntaxCorrect = false;
                    checkFalse = true;
                    break;
                }
                else if(syntax_line.toUpperCase().charAt(i+1) == ',' &&
                        syntax_line.toUpperCase().charAt(i+2) == 'F' && syntax_line.toUpperCase().charAt(i+3) == 'R' &&
                        syntax_line.toUpperCase().charAt(i+4) == 'O' && syntax_line.toUpperCase().charAt(i+5) == 'M'){
                    isSyntaxCorrect = false;
                    checkFalse = true;
                    break;
                }
                else if(syntax_line.toUpperCase().charAt(i+1) == 'F' && syntax_line.toUpperCase().charAt(i+2) == 'R' &&
                        syntax_line.toUpperCase().charAt(i+3) == 'O' && syntax_line.toUpperCase().charAt(i+4) == 'M' &&
                        Character.isLetterOrDigit(syntax_line.toUpperCase().charAt(i+5))){
                    isSyntaxCorrect = false;
                    checkFalse = true;
                    break;
                }
                else if(syntax_line.toUpperCase().charAt(i+1) == 'F' && syntax_line.toUpperCase().charAt(i+2) == 'R' &&
                        syntax_line.toUpperCase().charAt(i+3) == 'O' && syntax_line.toUpperCase().charAt(i+4) == 'M'){
                    if(!Character.isLetterOrDigit(syntax_line.toUpperCase().charAt(i-1))){
                        if(input.equals("")) {
                            isSyntaxCorrect = false;
                            checkFalse = true;
                            break;
                        }
                    }
                }
            }
        }
        if((start.equals("SELECT") || start.equals("SET") ||
                start.equals("DELETE") || start.equals("UPDATE")) && from.equals("FROM") && checkFalse == false){
            isSyntaxCorrect = true;
        } else isSyntaxCorrect = false;
    }
    @FXML
    void inputButtonOnclick(ActionEvent event) {
        fillTaskArea();
 //       fillSqlTextArrea();
    }

    private void fillTaskArea() {
        String filePath = createFileChooser().showOpenDialog(null).getAbsolutePath();
        Path path = Paths.get(filePath);
        String txt = "";
        int cnt = 0;
        try {
            lines2 = Files.readAllLines(path,
                    Charset.defaultCharset());
            numberOfSyntaxLines = 1;//Integer.parseInt(numberStr);      //geht nicht vorübergehend = 1
            lines2 = lines2.stream().
                    skip(1)
                    .collect(Collectors.toList());
            for (String line : lines2) {
                cnt++;
                txt = txt + line + "\n";
            }
            taskTextArea.setText(txt);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
/*    private void fillSqlTextArrea() {
        String filePath = createFileChooser().showOpenDialog(null).getAbsolutePath();
        Path path = Paths.get(filePath);
        String txt = "";
        int cnt = 0;
        try {
            lines = Files.readAllLines(path,
                    Charset.defaultCharset());
            for (String line : lines) {
                cnt++;
                txt = txt + line + "\n";
            }
            numberOfSqlLines = cnt;
            textArea.setText(txt);
            msgLabel.setText(cnt + " lines have been imported!");
            isCorrecto();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/
    private void isCorrecto() {
        if (numberOfSyntaxLines == numberOfSqlLines) isSyntaxCorrect = true;
        else isSyntaxCorrect = false;
    }
    private FileChooser createFileChooser(){
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select SQL");
        fileChooser.setInitialDirectory(new File("."));
        choosenFile = fileChooser.getInitialFileName();
        FileChooser.ExtensionFilter extFilterJPG
                = new FileChooser.ExtensionFilter("SQL files (*.sql)", "*.sql", ".SQL");
        fileChooser.getExtensionFilters().addAll(extFilterJPG);
        return fileChooser;
    }
}