package controller;

        import javafx.event.ActionEvent;
        import javafx.fxml.FXML;
        import javafx.scene.control.Label;
        import javafx.scene.control.TextArea;
        import javafx.scene.control.TextField;
        import javafx.stage.FileChooser;

        import javax.xml.soap.Text;
        import java.awt.*;
        import java.io.File;
        import java.io.IOException;
        import java.nio.charset.Charset;
        import java.nio.file.Files;
        import java.nio.file.Path;
        import java.nio.file.Paths;
        import java.util.List;
        import java.util.stream.Collectors;

public class Controller {
    @FXML
    private TextArea textArea;

    @FXML
    private Label msgLabel;

    @FXML
    private TextField syntaxCorrectField;

    @FXML
    private TextArea taskTextArea;

    boolean isSyntaxCorrect = true;

    int numberOfSyntaxLines = 0;
    int numberOfSqlLines = 0;

    private List<String> lines = null;
    private List<String> lines2 = null;

    @FXML
    void checkButtonOnCLick(ActionEvent event) { // es gibt einen FEHLER
        if (lines == null){
            msgLabel.setText("The file is empty or you didn't import it yet!");
        }else{
            for (int i = 0; i < lines.size(); i++){
                String mystring = lines.get(i);
                String arr[] = mystring.split(" ", 2);
                System.out.println("fw: " + arr[0] + "  |  rest: " + arr[1]);
            }
        }

        checkColumns();

        if(isSyntaxCorrect) {
            syntaxCorrectField.setStyle("-fx-background-color: green;");
            syntaxCorrectField.setText("Syntax korrekt");
        }
        else {
            syntaxCorrectField.setStyle("-fx-text-base-color: red;");
            syntaxCorrectField.setText("Syntax inkorrekt!");
        }
    }

    private void checkColumns()
    {
        String line = lines.get(0);
        int start = 0;
        int end = 0;

        for(int i = 0; i < line.length();i++){
            if('S' == line.toUpperCase().charAt(i)){
                String s = "S";
                int count = 0;
                for(int r = i; count < 5;r++){
                    s += line.toUpperCase().charAt(r);
                    count++;
                }
                if(s == "SELECT"){
                    start = i+6;
                }
            }
            if('F' == line.toUpperCase().charAt(1)){
                String s = "S";
                int count = 0;
                for(int r = i; count < 4;r++){
                    s += line.toUpperCase().charAt(r);
                    count++;
                }
                if(s == "SELECT"){
                    end = i-1;
                }
            }
        }
        if(end != 0) {
            String s = "";
            for (int i = start; i <= end; i++) {
                s += lines.get(i);
            }
            String[] arr = s.split(",");
            if (arr.length == 5) {         //vorübergehen 5 später wird aus dem taskfile die anzahl der spalten erhalten
                isSyntaxCorrect = true;
            }
            else{
                isSyntaxCorrect = false;
            }
        }
        else {
            isSyntaxCorrect = false;
        }
    }



    @FXML
    void inputButtonOnclick(ActionEvent event) {
        fillTaskArea();
        fillSqlTextArrea();
    }

    private void fillTaskArea() {
        String filePath = createFileChooser().showOpenDialog(null).getAbsolutePath();
        Path path = Paths.get(filePath);
        String txt = "";
        int cnt = 0;
        try {
            lines2 = Files.readAllLines(path,
                    Charset.defaultCharset());
            //String numberStr = String.valueOf(lines2.get(0).split("--"));
            numberOfSyntaxLines = 1;//Integer.parseInt(numberStr);      //geht nicht vorübergehend = 1

            lines2 = lines2.stream().
                    skip(1)
                    .collect(Collectors.toList());

            for (String line : lines2) {
                cnt++;
                txt = txt + line + "\n";
            }
            taskTextArea.setText(txt);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void fillSqlTextArrea() {
        String filePath = createFileChooser().showOpenDialog(null).getAbsolutePath();
        Path path = Paths.get(filePath);
        String txt = "";
        int cnt = 0;
        try {
            lines = Files.readAllLines(path,
                    Charset.defaultCharset());

            for (String line : lines) {
                cnt++;
                txt = txt + line + "\n";
            }
            numberOfSqlLines = cnt;
            textArea.setText(txt);
            msgLabel.setText(cnt + " lines have been imported!");

            isCorrecto();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void isCorrecto() {
        if (numberOfSyntaxLines == numberOfSqlLines) isSyntaxCorrect = true;
        else isSyntaxCorrect = false;
    }

    private FileChooser createFileChooser(){
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select SQL");
        fileChooser.setInitialDirectory(new File("."));
        FileChooser.ExtensionFilter extFilterJPG
                = new FileChooser.ExtensionFilter("SQL files (*.sql)", "*.sql", ".SQL");
        fileChooser.getExtensionFilters().addAll(extFilterJPG);
        return fileChooser;
    }
}