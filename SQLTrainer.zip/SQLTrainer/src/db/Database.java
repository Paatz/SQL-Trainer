package db;

import java.sql.*;

public class Database {
    static final String CONNECTION_STRING = "jdbc:mariadb://192.168.99.100:3306/mydb";
    static final String USER = "user";
    static final String PASSWORD = "passme";

    private Connection connection;
    private static Database instance;

    private Database() throws SQLException {
        try{
            connection = DriverManager.getConnection(CONNECTION_STRING,USER,PASSWORD);
            connection.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
            connection.setAutoCommit(true);
            System.out.println("Verbindung erfolgreich");
        }
        catch(SQLException e){
            System.out.println("Verbindung zur DB nicht möglich");
            System.err.println(e.getMessage());
        }
    }

    /**
     * Singleton-Zugriff
     **/
    public static Database getInstance() throws SQLException {
        if (instance == null) {
            instance = new Database();
        }
        return instance;
    }

    public Boolean tableExist(String table){
        Boolean ret = true;
        String sql = "SHOW TABLES LIKE " + "'" + table + "'";
        try(PreparedStatement stmt = connection.prepareStatement(sql)){
            stmt.execute();
        }
        catch(Exception e){
            return false;
        }
        return ret;
    }

    public int countRows(String sql) throws SQLException {
        PreparedStatement stmt = connection.prepareStatement(sql);
        ResultSet resultSet = stmt.executeQuery(sql);
        int count = 0;
        while (resultSet.next()) {
            count++;
        }
        return count;
    }
}
